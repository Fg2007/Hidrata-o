package br.ulbra.example.hidrateichon;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edtpeso, edtano, edtagua;
    TextView txtgota, txthidrata, txtatividade, txtresultado;
    RadioButton rbsedentario, rbmoderado, rbintenso;
    Button btncalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtagua = findViewById(R.id.edtagua);
        edtano = findViewById(R.id.edtano);
        edtpeso = findViewById(R.id.edtpeso);

        txtatividade = findViewById(R.id.txtatividade);
        txtgota = findViewById(R.id.txtgota);
        txthidrata = findViewById(R.id.txthidrata);
        txtresultado = findViewById(R.id.txtresultado);

        rbsedentario = findViewById(R.id.rbsedentario);
        rbmoderado = findViewById(R.id.rbmoderado);
        rbintenso = findViewById(R.id.rbintenso);

        btncalcular = findViewById(R.id.btncalcular);

        btncalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (edtpeso.getText().toString().isEmpty() ||
                        edtano.getText().toString().isEmpty() ||
                        edtagua.getText().toString().isEmpty()) {

                    txtresultado.setText("Preencha todos os campos!");
                    return;
                }
                double peso = Double.parseDouble(edtpeso.getText().toString());
                int idade = Integer.parseInt(edtano.getText().toString());
                double aguaAtual = Double.parseDouble(edtagua.getText().toString());
                if (peso <= 0 || idade <= 0) {

                    txtresultado.setText("Digite valores válidos!");
                    return;
                }
                int extra = 0;
                if (rbsedentario.isChecked()) {
                    extra = 0;
                }
                if (rbmoderado.isChecked()) {
                    extra = 300;
                }
                if (rbintenso.isChecked()) {
                    extra = 600;
                }
                double consumoBase = peso * 35;
                double consumoTotal = consumoBase + extra;
                double restante = consumoTotal - aguaAtual;
                if (restante < 0) {
                    restante = 0;
                }
                txtresultado.setText(
                        "Meta diária: " +
                                String.format("%.0f", consumoTotal) +
                                " ml\n\n" +

                                "Consumido hoje: " +
                                String.format("%.0f", aguaAtual) +
                                " ml\n\n" +

                                "Faltam: " +
                                String.format("%.0f", restante) +
                                " ml para atingir a meta."

                );

            }
        });

    }
}